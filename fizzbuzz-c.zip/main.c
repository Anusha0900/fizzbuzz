/* the fizzbuzz problem: output values from 1 to x and print fizz if the number is divisible by 3 
print buzz if the number is divisible by 5 
print fizzbuzz if the number is divisible by 3 and 5 both
*/
#include<stdio.h>
void fizzbuzz(int);
int main()
{
    int x;
    printf("Enter the value of x of the last limit upto which you want to print numbers\n");
    scanf("%d", &x);
    fizzbuzz(x);
    return 0;
}

void fizzbuzz(int x)
{
    int i;
    for(i=1; i<=x; i++){
        if(i%3==0 && i%5==0)
        printf("FizzBuzz\n");
        
        else if(i%3==0)
        printf("Fizz\n");
        
        else if(i%5==0)
        printf("Buzz\n");
        
        else
        printf("%d\n", i);
    }
}
/*eg, x= 20 
1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20
output: 1, 2, fizz, 4, buzz, fizz, 7, 8, fizz, buzz, 11, fizz, 13, 14, fizzbuzz, 16, 17, fizz, 19, buzz
*/
